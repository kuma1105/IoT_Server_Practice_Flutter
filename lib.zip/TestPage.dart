import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
import 'package:flutter_dev/dio_server.dart';

class TestPage extends StatelessWidget {
  const TestPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orangeAccent,
      ),
      body:
          // Center(
          //     child: InkWell(
          //         onTap: () {
          //           Get.back();
          //         },
          //         child: Text('hi'))),
          Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          FlatButton(
              color: Colors.orangeAccent,
              onPressed: () {
                server.getReq();
              },
              child: Text("GET")),
          FlatButton(
              color: Colors.orangeAccent,
              onPressed: () {
                server.postReq();
              },
              child: Text("POST")),
          FlatButton(
              color: Colors.orangeAccent,
              onPressed: () {
                server.getReqWzQuery();
              },
              child: Text("GET WITH QUERY")),
        ],
      ),
    );
  }
}
