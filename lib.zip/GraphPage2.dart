import 'package:flutter/material.dart';
import 'dart:math';
import 'package:flutter_dev/dio_server.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // const ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chart Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GraphPage2(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class GraphPage2 extends StatelessWidget {
  List<double> points = [50, 0, 73, 100, 150, 120, 200, 80];

  @override
  Widget build(BuildContext context) {
    // int humid = 50; //이 쪽으로 값 받기

    return Scaffold(
      appBar: AppBar(
        title: Text("Chart Page"),
      ),
      body: Container(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Center(
          child: Column(
            // crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                child: CustomPaint(
                  // CustomPaint를 그리고 이 안에 차트를 그려줍니다..
                  size:
                      Size(300, 300), // CustomPaint의 크기는 가로 세로 150, 150으로 합니다.
                  painter: PieChart(
                      percentage: 60, // 파이 차트가 얼마나 칠해져 있는지 정하는 변수입니다.
                      textScaleFactor: 1.0, // 파이 차트에 들어갈 텍스트 크기를 정합니다.
                      textColor: Colors.black),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              TextButton(
                  onPressed: () {
                    print("새로고침 버튼을 눌렀습니다. 서버로부터 값을 받아옵니다.");
                    server.getReq();
                  },
                  child: Text(
                    "Update",
                    style: TextStyle(color: Colors.black, fontSize: 30),
                  ),
                  style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all<Color>(Colors.blue[200])))
            ],
          ),
        ),
      ),
    );
  }
}

class PieChart extends CustomPainter {
  int percentage = 0;
  double textScaleFactor = 1.0;
  Color textColor;

  PieChart({this.percentage, this.textScaleFactor, this.textColor});

  @override
  //원
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 30.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    double radius = min(size.width / 2 - paint.strokeWidth / 2,
        size.height / 2 - paint.strokeWidth / 2);
    Offset center = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(center, radius, paint);
    drawArc(paint, canvas, center, radius);
    drawText(canvas, size, "$percentage%");
  }

  //값 받을 곳
  void drawArc(Paint paint, Canvas canvas, Offset center, double radius) {
    double arcAngle = 2 * pi * (percentage / 100);
    paint..color = Colors.blueAccent;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -pi / 2,
        arcAngle, false, paint);
  }

  void drawText(Canvas canvas, Size size, String text) {
    double fontSize = getFontSize(size, text);
    TextSpan sp = TextSpan(
      style: TextStyle(
          fontSize: fontSize, fontWeight: FontWeight.bold, color: textColor),
      text: text,
    );
    TextPainter tp = TextPainter(text: sp, textDirection: TextDirection.ltr);

    tp.layout();
    double dx = size.width / 2 - tp.width / 2;
    double dy = size.height / 2 - tp.height / 2;

    Offset offset = Offset(dx, dy);
    tp.paint(canvas, offset);
  }

  double getFontSize(Size size, String text) {
    return size.width / text.length * textScaleFactor;
  }

  @override
  bool shouldRepaint(PieChart old) {
    return old.percentage != percentage;
  }
}

// class GraphPage2 extends StatelessWidget {
//   const GraphPage2({Key key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: Text("GraphPage"),
//         ),
//         body: CustomPaint(
//           size: Size(200, 200),
//           // painter: MyPainter(),
//           foregroundPainter: MyPainter(),
//           child: Container(
//             width: 200,
//             height: 200,
//             color: Colors.green,
//           ),
//         ));
//   }
// }

// class MyPainter extends CustomPainter {
//   @override
//   void paint(Canvas canvas, Size size) {
//     Paint paint = Paint()
//       ..strokeWidth = 5.0
//       ..style = PaintingStyle.stroke
//       ..color = Colors.red;
//     Path path = Path();
//     path.moveTo(0.0, 0.0); // (0.0, 0.0) 좌표로 이동
//     path.lineTo(120.0, 120.0); // 시작점에서 (120.0, 120.0) 까지 선을 그음
//     canvas.drawPath(path, paint);
//   }

//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegete) {
//     return false;
//   }
// }
