import 'package:dio/dio.dart';
import 'RESTjson.dart';
import 'dart:convert'; //jsonDecode를 사용하기 위해
// import 'package:http/http.dart' as http;

const _API_PREFIX = "https://jsonplaceholder.typicode.com/posts";

class Server {
  Future<void> getReq() async {
    Response response;
    Dio dio = new Dio();
    response = await dio.get("$_API_PREFIX/1");
    print(response);
    // if (response.statusCode == 200) {
    //   print("200");
    //   final jsonBody = json.decode(response);
    //   print(jsonBody);
    // }

    //   print(responseMap);
    //   var user = Json.fromJson(responseMap);
    //   print(user.id);
  }

  Future<void> postReq() async {
    Response response;
    Dio dio = new Dio();

    Map<String, dynamic> data = {"id": 12, "name": "vidtorianoch!!!"};
    data.putIfAbsent("userId", () => 189);
    response = await dio.post(_API_PREFIX, data: data);
    print(response.data.toString());
  }

  Future<void> getReqWzQuery() async {
    Response response;
    Dio dio = new Dio();

    response = await dio.get(_API_PREFIX, queryParameters: {
      "userId": 1,
      "id": 2,
      //userid = 1, id = 2인 데이터를 모두 받아온다.
    });
    print(response.data.toString());
  }
}

Server server = Server();
