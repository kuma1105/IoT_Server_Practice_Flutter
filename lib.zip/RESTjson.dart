import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class Json {
  final int userId;
  final int id;
  final String title;
  final String body;

  Json(this.userId, this.id, this.title, this.body);

  Json.fromJson(Map<String, dynamic> json)
      : userId = json['userId'],
        id = json['id'],
        title = json['title'],
        body = json['body'];

  // Map<String, dynamic> toJson() => {
  //       'tmp': tmp,
  //       'hum': hum,
  //       'alert': alert,
  //     };
}
